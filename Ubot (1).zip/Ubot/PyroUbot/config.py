import os
from dotenv import load_dotenv

load_dotenv(".env")

MAX_BOT = int(os.getenv("MAX_BOT", "200"))

DEVS = list(map(int, os.getenv("DEVS", "7560407350").split()))

API_ID = int(os.getenv("API_ID", "25928222"))

API_HASH = os.getenv("API_HASH", "e1daea0d17cc64126664e8402cb8e7ab")

BOT_TOKEN = os.getenv("BOT_TOKEN", "8158531544:AAEAo1TYm_7JuWFQuY-MYFgX0C9YR3pmhe8")

OWNER_ID = int(os.getenv("OWNER_ID", "7560407350"))

BLACKLIST_CHAT = list(map(int, os.getenv("BLACKLIST_CHAT", "-1002312835928").split()))

RMBG_API = os.getenv("RMBG_API", "a6qxsmMJ3CsNo7HyxuKGsP1o")

MONGO_URL = os.getenv("MONGO_URL", "mongodb+srv://dbsatan:dbsatan@cluster0.bbao9oj.mongodb.net/?retryWrites=true&w=majority&appName=Cluster0")

LOGS_MAKER_UBOT = int(os.getenv("LOGS_MAKER_UBOT", "-1002827475566"))
